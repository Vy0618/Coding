package com.devsenai1A.calculadora;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Calculadora1Application {

	public static void main(String[] args) {
		SpringApplication.run(Calculadora1Application.class, args);
	}

}
