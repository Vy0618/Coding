package com.devsenai1A.calculadora;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Calculadora1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
